"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CalendarDays, Home, Phone, Star } from "lucide-react";
import { motion } from "framer-motion";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white text-gray-800 px-4 md:px-16 py-8 space-y-12">
      {/* Header */}
      <header className="text-center space-y-2">
        <h1 className="text-4xl font-bold text-gray-900">Everstone Homes</h1>
        <p className="text-lg text-gray-600">Comfortable, affordable stays—wherever you go.</p>
      </header>

      {/* Featured Properties */}
      <section>
        <h2 className="text-2xl font-semibold mb-6">Our Homes</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {[1, 2, 3].map((id) => (
            <Card key={id} className="rounded-2xl shadow-md">
              <CardContent className="p-4 space-y-2">
                <div className="h-48 bg-gray-200 rounded-xl" />
                <h3 className="text-xl font-semibold">Home {id}</h3>
                <p className="text-sm text-gray-600">2 Bed • Wi-Fi • Kitchen • Free Parking</p>
                <div className="flex justify-between items-center pt-2">
                  <span className="text-primary font-semibold">UGX 250,000/night</span>
                  <Button size="sm">Book Now</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Reviews */}
      <section>
        <h2 className="text-2xl font-semibold mb-6">Guest Reviews</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {['Alaine', 'Kirsten'].map((name, idx) => (
            <Card key={idx} className="rounded-2xl shadow-sm border border-gray-200">
              <CardContent className="p-4 space-y-2">
                <div className="flex items-center gap-2">
                  <Star className="w-5 h-5 text-yellow-500" />
                  <p className="font-semibold">{name}</p>
                </div>
                <p className="text-gray-600 text-sm italic">
                  {name === 'Alaine' ?
                    "Alaine was so understanding and easy to host. Truly a joy!" :
                    "Kirsten was respectful, tidy, and a great communicator. Welcome back anytime!"
                  }
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Contact */}
      <section className="text-center space-y-4">
        <h2 className="text-2xl font-semibold">Get In Touch</h2>
        <p className="text-gray-600">Looking to book directly or have a question?</p>
        <div className="flex justify-center gap-4">
          <Button variant="outline" className="flex items-center gap-2">
            <Phone className="w-4 h-4" /> Call Us
          </Button>
          <Button className="flex items-center gap-2">
            <CalendarDays className="w-4 h-4" /> WhatsApp
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="text-center text-sm text-gray-400 pt-12">
        © {new Date().getFullYear()} Everstone Homes. All rights reserved.
      </footer>
    </div>
  );
}
